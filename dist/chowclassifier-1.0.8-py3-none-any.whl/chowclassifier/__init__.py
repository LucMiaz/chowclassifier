# __init__.py

# Version of the chowclassifier package
__version__ = "1.0.8"
from chowclassifier.chow import Chow
from chowclassifier.chewdata import ChewData
